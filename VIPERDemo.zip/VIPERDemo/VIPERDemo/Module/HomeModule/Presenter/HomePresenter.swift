//
//  HomePresenter.swift
//  VIPERDemo
//
//  Created by mac on 09/03/23.
//

//MARK: - HomePresenterProtocol
protocol HomeInteractorToPresenterProtocol: AnyObject {
    func didFetchNews()
    func didFailFetchNews(error: String)
    func loading(isLoading: Bool)
}

protocol HomeViewToPresenterProtocol: AnyObject {
    var view: HomePresenterToViewProtocol? { get set }
    var interactor: HomePresenterToInteractorProtocol? { get set }
    var router: HomePresenterToRouterProtocol? { get set }
    
    func viewdidLoad()
    func getNewsListCount() -> Int
    func getNews(at index: Int) -> LiveNewsModel?
}

//MARK: - HomePresenter
class HomePresenter: HomeViewToPresenterProtocol {
    weak var view: HomePresenterToViewProtocol?
    var interactor: HomePresenterToInteractorProtocol?
    var router: HomePresenterToRouterProtocol?
    
    func viewdidLoad() {
        interactor?.getLiveNews()
    }
    
    func getNewsListCount() -> Int {
        return interactor?.news?.count ?? 0
    }
    
    func getNews(at index: Int) -> LiveNewsModel? {
        return interactor?.news?[index]
    }
    
}

//MARK: - Extension HomePresenterProtocol
extension HomePresenter: HomeInteractorToPresenterProtocol {
    func didFailFetchNews(error: String) {
        view?.showError(error: error)
    }
    
    func loading(isLoading: Bool) {
        view?.loader(isLoading: isLoading)
    }
    
    func didFetchNews() {
        view?.newsData()
    }
}
