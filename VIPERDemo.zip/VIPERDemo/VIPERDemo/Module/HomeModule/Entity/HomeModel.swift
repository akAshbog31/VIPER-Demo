//
//  HomeModel.swift
//  VIPERDemo
//
//  Created by mac on 09/03/23.
//

import UIKit

struct NewsResponse: Convertable {
    let status: String?
    let source: String?
    let sortBy: String?
    let articles: [LiveNewsModel]?
}

struct LiveNewsModel: Convertable {
    let author: String?
    let title: String?
    let description: String?
    let url: String?
    let urlToImage: String?
    let publishedAt: String?
}


