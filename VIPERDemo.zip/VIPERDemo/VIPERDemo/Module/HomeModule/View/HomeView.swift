//
//  HomeView.swift
//  VIPERDemo
//
//  Created by mac on 09/03/23.
//

//MARK: - HomeViewProtocol
protocol HomePresenterToViewProtocol: AnyObject {
    func loader(isLoading: Bool)
    func showError(error: String)
    func newsData()
}

