//
//  NetworkManager.swift
//  VIPERDemo
//
//  Created by mac on 09/03/23.
//

import Foundation
import Moya

typealias complition<T: Convertable> = (Result<T, Error>) -> Void

final class NetworkManager: Networkable {
    var provider = MoyaProvider<VIPERDemo>(plugins: [NetworkLoggerPlugin(configuration: .init(formatter: .init(), output: { target, items in
        if let log = items.first {
            print(log)
        }
    }, logOptions: .formatRequestAscURL))])
    
    func fetchLiveNews(complition: @escaping complition<NewsResponse>) {
        request(target: .articles(source: "techcrunch", apiKey: "17cf1b333e964cea91e89e1e824bd366"), complition: complition)
    }
}

extension NetworkManager {
    private func request<T: Convertable>(target: VIPERDemo, complition: @escaping complition<T>) {
        provider.request(target) { result in
            switch result {
            case .success(let response):
                do {
                    let results = try JSONDecoder().decode(T.self, from: response.data)
                    complition(.success(results))
                } catch let error {
                    complition(.failure(error))
                }
            case .failure(let error):
                complition(.failure(error))
            }
        }
    }
}
