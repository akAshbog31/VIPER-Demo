//
//  HomeVc.swift
//  VIPERDemo
//
//  Created by mac on 09/03/23.
//

import UIKit

class HomeVc: UIViewController {
    //MARK: - @IBOutlet
    @IBOutlet weak var tblNews: UITableView!
    
    //MARK: - Properties
    var presenter: HomeViewToPresenterProtocol?
    
    //MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setTblView()
        presenter?.viewdidLoad()
    }
    
    //MARK: - @IBAction
    
    //MARK: - Functions
    private func setTblView() {
        tblNews.delegate = self
        tblNews.dataSource = self
        tblNews.registerNib(cell: NewsListCell.self)
    }
    
}

//MARK: -
extension HomeVc: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return presenter?.getNewsListCount() ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.deque() as NewsListCell
        guard let news = presenter?.getNews(at: indexPath.row) else { return .init() }
        cell.setCell(title: news.title ?? "", author: news.author ?? "", description: news.description ?? "")
        return cell
    }
}

//MARK: - HomeViewProtocol
extension HomeVc: HomePresenterToViewProtocol {
    func loader(isLoading: Bool) {
        isLoading ? self.showHUD() : self.dismissHUD()
    }
    
    func showError(error: String) {
        self.showAlert(msg: error)
    }
    
    func newsData() {
        tblNews.reloadData()
    }
}

