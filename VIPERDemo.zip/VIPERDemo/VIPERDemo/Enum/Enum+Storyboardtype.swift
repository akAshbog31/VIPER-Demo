//
//  Enum+Storyboardtype.swift
//  Summit
//
//  Created by mac on 22/12/22.
//

import Foundation

enum StoryboardType: String {
    case main = "Main"
    case dashboard = "Dashboard"
}
