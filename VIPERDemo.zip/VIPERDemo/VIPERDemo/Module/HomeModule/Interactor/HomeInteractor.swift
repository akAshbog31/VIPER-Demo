//
//  HomeInteractor.swift
//  VIPERDemo
//
//  Created by mac on 09/03/23.
//


//MARK: - HomeInteractorProtocol
protocol HomePresenterToInteractorProtocol {
    var networkable: Networkable { get set }
    var presenter: HomeInteractorToPresenterProtocol? { get set }
    var news: [LiveNewsModel]? { get set }
    
    func getLiveNews()
}

//MARK: - HomeInteractor
class HomeInteractor: HomePresenterToInteractorProtocol {
    var networkable: Networkable
    weak var presenter: HomeInteractorToPresenterProtocol?
    var news: [LiveNewsModel]?
    
    
    init(networkable: Networkable = NetworkManager()) {
        self.networkable = networkable
    }
    
    func getLiveNews() {
        presenter?.loading(isLoading: true)
        networkable.fetchLiveNews { [weak self] result in
            self?.presenter?.loading(isLoading: false)
            switch result {
            case .success(let json):
                self?.news = json.articles
                self?.presenter?.didFetchNews()
            case .failure(let error):
                self?.presenter?.didFailFetchNews(error: error.localizedDescription)
            }
        }
    }
}
