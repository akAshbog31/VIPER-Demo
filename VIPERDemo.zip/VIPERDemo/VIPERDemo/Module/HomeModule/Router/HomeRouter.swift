//
//  HomeRouter.swift
//  VIPERDemo
//
//  Created by mac on 09/03/23.
//

import UIKit

//MARK: - HomeRouterProtocol
protocol HomePresenterToRouterProtocol {
    static func build() -> UIViewController
}

//MARK: - HomeRouter
class HomeRouter: HomePresenterToRouterProtocol {
    static func build() -> UIViewController {
        let homeVc: HomeVc = HomeVc.instantiate()
        let presenter: HomeViewToPresenterProtocol & HomeInteractorToPresenterProtocol = HomePresenter()
        var interactor: HomePresenterToInteractorProtocol = HomeInteractor()
        let router: HomePresenterToRouterProtocol = HomeRouter()
        
        homeVc.presenter = presenter
        presenter.view = homeVc
        presenter.interactor = interactor
        presenter.router = router
        interactor.presenter = presenter
        return homeVc
    }
}

