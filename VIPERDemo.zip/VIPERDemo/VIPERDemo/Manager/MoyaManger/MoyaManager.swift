//
//  MoyaManager.swift
//  VIPERDemo
//
//  Created by mac on 09/03/23.
//

import Moya

enum VIPERDemo {
    case articles(source: String, apiKey: String)
}

extension VIPERDemo: TargetType {
    var baseURL: URL {
        return URL(string: "https://newsapi.org/v1")!
    }
    
    var path: String {
        switch self {
        case .articles:
            return "/articles"
        }
    }
    
    var method: Method {
        switch self {
        case .articles:
            return .get
        }
    }
    
    var task: Task {
        switch self {
        case .articles(let source, let apiKey):
            return .requestParameters(parameters: ["source": source, "apiKey": apiKey], encoding: URLEncoding.queryString)
        }
    }
    
    var headers: [String : String]? {
        switch self {
        case .articles:
            return ["Content-Type": "application/json"]
        }
    }
    
    
}
