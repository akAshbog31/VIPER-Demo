//
//  Networkable.swift
//  VIPERDemo
//
//  Created by mac on 09/03/23.
//

import Moya

protocol Networkable {
    var provider: MoyaProvider<VIPERDemo> { get set }
    
    func fetchLiveNews(complition: @escaping complition<NewsResponse>)
}
